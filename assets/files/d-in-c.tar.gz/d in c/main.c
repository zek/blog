#include <stdio.h>

void C_fonksiyonu(){
    printf("C_fonksiyonu çağırıldı\n");
}


int main(){
    int ll = D_fonksiyonu(1000);
    printf("%i\n", ll);
    return 0;
}