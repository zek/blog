#include <stdio.h>

int C_fonksiyonu(int val){
    printf("C_fonksiyonu çağırıldı\n");
    D_fonksiyonu();
    return val;
}